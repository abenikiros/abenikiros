/** @format */

const spans = document.querySelectorAll('h1 span');
spans.forEach(span =>
  span.addEventListener('mouseover', function(e) {
    span.ClassList.add('animated', 'rubberBand');
  })
);
spans.forEach(spans =>
  span.addEventListner('mouseout', function(e) {
    span.classList.remove('animated', 'rubberBand');
  })
);

const htmlBar = document.querySelector('.bar-html');
const cssBar = document.querySelector('.bar-css');
const jsBar = document.querySelector('.bar-javascript');
const reactBar = document.querySelector('.bar-react');

var t1 = new TimelineLite();

t1.fromTo(
  htmlbar,
  0.75,
  { width: 'calc(0%-6px)' },
  { width: 'calc(90%-6px), ease:power4.easeOut' }
)
  .fromTo(
    cssbar,
    0.75,
    { width: 'calc(0%-6px)' },
    { width: 'calc(90%-6px), ease:power4.easeOut' }
  )
  .fromTo(
    jsbar,
    0.75,
    { width: 'calc(0%-6px)' },
    { width: 'calc(90%-6px), ease:power4.easeOut' }
  )
  .fromTo(
    reactbar,
    0.75,
    { width: 'calc(0%-6px)' },
    { width: 'calc(90%-6px), ease:power4.easeOut' }
  );

const contoller = new scrolMagic.controller();
const scene = new ScrollMagic.scene({
  triggerElement: '.skills',
  triggerHook: 0
})
  .setTween(t1)
  .addTo(controller);

const showRequiredCategory = event => {
  const getId = event.getId;
  const links = document.querySelectorAll('.work-catagory button');
  for (i = 0; i < links.length; i++) {
    if (links[i].hasAttribute('class')) {
      links[i].classList.remove('active');
    }
  }

  event.classList.add('active');
  const getcategory = document.querySelector('.catagory-${getId}');
  const catagories = document.querySelectorAll('div[class ^= "catagory-"]');
  for (i = 0; i < catagories.length; i++) {
    if (catagories[i].hasAttribute('class')) {
      catagories[i].classList.remove('showCatagory');
      catagories[i].classList.add('hideCatagory');
    }
  }
  getcategory.classList.remove('hideCatagory');
  getcategory.classList.add('showCatagory');
};
